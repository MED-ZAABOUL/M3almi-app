// ══════════════════════════════════════════════════════════════
//  maalam_dashboard.dart — Teacher (Maalam) Dashboard
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'main.dart';

class MaalamDashboard extends StatefulWidget {
  const MaalamDashboard({super.key});
  @override
  State<MaalamDashboard> createState() => _MaalamDashboardState();
}

class _MaalamDashboardState extends State<MaalamDashboard> with TickerProviderStateMixin {
  int _navIndex = 0;
  late final AnimationController _headerCtrl;
  late final AnimationController _contentCtrl;

  @override
  void initState() {
    super.initState();
    _headerCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 700))..forward();
    _contentCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600));
    Future.delayed(const Duration(milliseconds: 200), _contentCtrl.forward);
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    _contentCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: M3Colors.bg,
        body: Column(
          children: [
            _buildHeader(),
            Expanded(child: _buildBody()),
          ],
        ),
        bottomNavigationBar: _buildBottomNav(),
      ),
    );
  }

  // ── Header ──────────────────────────────────────────────────
  Widget _buildHeader() {
    return SlideTransition(
      position: Tween<Offset>(begin: const Offset(0, -0.3), end: Offset.zero)
          .animate(CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic)),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [M3Colors.petrolDark, M3Colors.petrol, Color(0xFF006AAC)],
            stops: [0, 0.6, 1],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
            child: Column(
              children: [
                // Top row
                Row(
                  children: [
                    // Logo mark
                    Container(
                      width: 44, height: 44,
                      decoration: BoxDecoration(
                        color: M3Colors.green,
                        borderRadius: BorderRadius.circular(13),
                        boxShadow: [BoxShadow(color: M3Colors.green.withOpacity(0.4), blurRadius: 12, offset: const Offset(0, 4))],
                      ),
                      child: const Icon(Icons.construction_rounded, color: Colors.white, size: 24),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('م3علمي PRO', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w900, color: Colors.white)),
                        Text('لوحة تحكم المعلم', style: GoogleFonts.cairo(fontSize: 11, color: Colors.white54)),
                      ],
                    ),
                    const Spacer(),
                    // Notification bell
                    Stack(
                      children: [
                        Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                          child: const Icon(Icons.notifications_outlined, color: Colors.white, size: 22),
                        ),
                        Positioned(
                          top: 6, left: 6,
                          child: Container(
                            width: 9, height: 9,
                            decoration: const BoxDecoration(color: M3Colors.red, shape: BoxShape.circle),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white.withOpacity(0.2)),
                      ),
                      child: const Center(child: Text('🧑‍🔧', style: TextStyle(fontSize: 20))),
                    ),
                  ],
                ),
                const SizedBox(height: 20),
                // Balance card
                Container(
                  padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.10),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: Colors.white.withOpacity(0.15)),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                const Icon(Icons.account_balance_wallet_outlined, color: M3Colors.green, size: 16),
                                const SizedBox(width: 6),
                                Text('رصيدي', style: GoogleFonts.cairo(fontSize: 12, color: Colors.white70, fontWeight: FontWeight.w600)),
                              ],
                            ),
                            const SizedBox(height: 4),
                            Text('1,240.50 ر.س', style: GoogleFonts.cairo(fontSize: 26, fontWeight: FontWeight.w900, color: Colors.white)),
                            const SizedBox(height: 3),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                              decoration: BoxDecoration(
                                color: M3Colors.green.withOpacity(0.2),
                                borderRadius: BorderRadius.circular(8),
                                border: Border.all(color: M3Colors.green.withOpacity(0.35)),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  const Icon(Icons.trending_up, color: M3Colors.green, size: 12),
                                  const SizedBox(width: 4),
                                  Text('+180 هذا الشهر', style: GoogleFonts.cairo(fontSize: 10.5, color: M3Colors.green, fontWeight: FontWeight.w700)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                      Column(
                        children: [
                          _headerActionBtn(icon: Icons.payments_outlined, label: 'سحب'),
                          const SizedBox(height: 8),
                          _headerActionBtn(icon: Icons.bar_chart_rounded, label: 'تقرير'),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _headerActionBtn({required IconData icon, required String label}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
      decoration: BoxDecoration(
        color: M3Colors.green,
        borderRadius: BorderRadius.circular(10),
        boxShadow: [BoxShadow(color: M3Colors.green.withOpacity(0.35), blurRadius: 8, offset: const Offset(0, 3))],
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, color: Colors.white, size: 14),
          const SizedBox(width: 4),
          Text(label, style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)),
        ],
      ),
    );
  }

  // ── Body ────────────────────────────────────────────────────
  Widget _buildBody() {
    return FadeTransition(
      opacity: CurvedAnimation(parent: _contentCtrl, curve: Curves.easeOut),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 20, 18, 20),
        children: [
          // Stats row
          _sectionTitle('إحصائياتك'),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: _statCard(icon: Icons.star_rounded, value: '4.9', label: 'التقييم', color: M3Colors.amber)),
              const SizedBox(width: 10),
              Expanded(child: _statCard(icon: Icons.check_circle_outline, value: '47', label: 'طلب مكتمل', color: M3Colors.green)),
              const SizedBox(width: 10),
              Expanded(child: _statCard(icon: Icons.pending_actions, value: '3', label: 'قيد التنفيذ', color: M3Colors.petrol)),
            ],
          ),
          const SizedBox(height: 24),

          // My services
          _sectionTitle('خدماتي'),
          const SizedBox(height: 12),
          ..._services.map((s) => _serviceCard(s)),
          const SizedBox(height: 8),
          // Add service button
          OutlinedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.add_circle_outline, color: M3Colors.petrol),
            label: Text('إضافة خدمة جديدة', style: GoogleFonts.cairo(color: M3Colors.petrol, fontWeight: FontWeight.w700)),
            style: OutlinedButton.styleFrom(
              side: const BorderSide(color: M3Colors.petrol, width: 1.5),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              padding: const EdgeInsets.symmetric(vertical: 13),
            ),
          ),
          const SizedBox(height: 24),

          // Pending orders
          _sectionTitle('الطلبات الواردة'),
          const SizedBox(height: 12),
          ..._orders.map((o) => _orderCard(o)),
        ],
      ),
    );
  }

  Widget _sectionTitle(String text) {
    return Row(
      children: [
        Text(text, style: GoogleFonts.cairo(fontSize: 14, fontWeight: FontWeight.w800, color: M3Colors.petrol)),
        const SizedBox(width: 8),
        Expanded(child: Divider(color: M3Colors.petrol.withOpacity(0.15), height: 1)),
      ],
    );
  }

  Widget _statCard({required IconData icon, required String value, required String label, required Color color}) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: color.withOpacity(0.1), blurRadius: 12, offset: const Offset(0, 3))],
        border: Border.all(color: color.withOpacity(0.12)),
      ),
      child: Column(
        children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 6),
          Text(value, style: GoogleFonts.cairo(fontSize: 18, fontWeight: FontWeight.w900, color: M3Colors.textPrimary)),
          Text(label, style: GoogleFonts.cairo(fontSize: 9.5, color: M3Colors.textMuted, fontWeight: FontWeight.w600), textAlign: TextAlign.center),
        ],
      ),
    );
  }

  Widget _serviceCard(Map<String, dynamic> s) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.06), blurRadius: 10, offset: const Offset(0, 3))],
      ),
      child: Row(
        children: [
          Container(
            width: 46, height: 46,
            decoration: BoxDecoration(
              color: M3Colors.petrolLight,
              borderRadius: BorderRadius.circular(13),
            ),
            child: Center(child: Text(s['emoji'], style: const TextStyle(fontSize: 22))),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(s['name'], style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w800, color: M3Colors.textPrimary)),
                const SizedBox(height: 2),
                Text('${s['price']} ر.س / ${s['unit']}', style: GoogleFonts.cairo(fontSize: 11.5, color: M3Colors.textSec)),
              ],
            ),
          ),
          // Active toggle indicator
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
            decoration: BoxDecoration(
              color: s['active'] ? M3Colors.greenTint : M3Colors.petrolLight,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: s['active'] ? M3Colors.green.withOpacity(0.3) : M3Colors.petrol.withOpacity(0.12)),
            ),
            child: Text(s['active'] ? 'نشطة' : 'موقوفة',
                style: GoogleFonts.cairo(fontSize: 10, fontWeight: FontWeight.w700,
                    color: s['active'] ? M3Colors.greenDark : M3Colors.textMuted)),
          ),
          const SizedBox(width: 8),
          Icon(Icons.more_vert, color: M3Colors.textMuted, size: 18),
        ],
      ),
    );
  }

  Widget _orderCard(Map<String, dynamic> o) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.08), blurRadius: 14, offset: const Offset(0, 4))],
        border: Border.all(color: M3Colors.petrol.withOpacity(0.08)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38, height: 38,
                decoration: BoxDecoration(color: M3Colors.petrolLight, shape: BoxShape.circle),
                child: Center(child: Text(o['avatar'], style: const TextStyle(fontSize: 18))),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(o['client'], style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w800, color: M3Colors.textPrimary)),
                    Text(o['service'], style: GoogleFonts.cairo(fontSize: 11, color: M3Colors.textSec)),
                  ],
                ),
              ),
              Text(o['price'], style: GoogleFonts.cairo(fontSize: 14, fontWeight: FontWeight.w900, color: M3Colors.petrol)),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(
                child: OutlinedButton(
                  onPressed: () {},
                  style: OutlinedButton.styleFrom(
                    side: const BorderSide(color: M3Colors.red),
                    foregroundColor: M3Colors.red,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  child: Text('رفض', style: GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.w700)),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                flex: 2,
                child: ElevatedButton(
                  onPressed: () {},
                  style: ElevatedButton.styleFrom(
                    backgroundColor: M3Colors.green,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    padding: const EdgeInsets.symmetric(vertical: 10),
                  ),
                  child: Text('قبول الطلب', style: GoogleFonts.cairo(fontSize: 12, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── Bottom Nav ───────────────────────────────────────────────
  Widget _buildBottomNav() {
    const items = [
      {'icon': Icons.home_rounded,       'label': 'الرئيسية'},
      {'icon': Icons.work_outline,       'label': 'خدماتي'},
      {'icon': Icons.chat_bubble_outline,'label': 'رسائل'},
      {'icon': Icons.person_outline,    'label': 'حسابي'},
    ];
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.08), blurRadius: 20, offset: const Offset(0, -4))],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            children: List.generate(items.length, (i) {
              final active = _navIndex == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _navIndex = i),
                  behavior: HitTestBehavior.opaque,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        height: 3,
                        margin: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: active ? M3Colors.petrol : Colors.transparent,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Icon(items[i]['icon'] as IconData,
                          color: active ? M3Colors.petrol : M3Colors.textMuted, size: 22),
                      const SizedBox(height: 3),
                      Text(items[i]['label'] as String,
                          style: GoogleFonts.cairo(
                              fontSize: 9.5, fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                              color: active ? M3Colors.petrol : M3Colors.textMuted)),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ── Mock Data ────────────────────────────────────────────────
  final _services = [
    {'emoji': '🔧', 'name': 'تمديدات السباكة', 'price': '150', 'unit': 'يوم', 'active': true},
    {'emoji': '💡', 'name': 'أعمال الكهرباء', 'price': '200', 'unit': 'يوم', 'active': true},
    {'emoji': '🎨', 'name': 'دهانات وديكور', 'price': '120', 'unit': 'م²', 'active': false},
  ];

  final _orders = [
    {'client': 'خالد المنصور', 'avatar': '👨', 'service': 'إصلاح تسرب مياه - الرياض', 'price': '350 ر.س'},
    {'client': 'سارة العتيبي', 'avatar': '👩', 'service': 'تركيب مروحة سقف', 'price': '180 ر.س'},
  ];
}
