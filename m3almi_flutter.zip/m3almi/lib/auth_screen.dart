// ══════════════════════════════════════════════════════════════
//  auth_screen.dart — Phone Login & Mock OTP Verification
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'main.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> with TickerProviderStateMixin {
  // ── State ──────────────────────────────────────────────────
  bool _showOtp = false;
  bool _loading = false;
  final _phoneCtrl = TextEditingController();
  final _otpCtrls  = List.generate(6, (_) => TextEditingController());
  final _otpFoci   = List.generate(6, (_) => FocusNode());
  final _phoneFocus = FocusNode();

  late final AnimationController _slideCtrl;
  late final Animation<Offset> _slideAnim;
  late final Animation<double> _fadeAnim;

  @override
  void initState() {
    super.initState();
    _slideCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 480));
    _slideAnim = Tween<Offset>(begin: const Offset(0.08, 0), end: Offset.zero)
        .animate(CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOutCubic));
    _fadeAnim  = CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOut);
    _slideCtrl.forward();
  }

  @override
  void dispose() {
    _slideCtrl.dispose();
    _phoneCtrl.dispose();
    for (final c in _otpCtrls) c.dispose();
    for (final f in _otpFoci)  f.dispose();
    _phoneFocus.dispose();
    super.dispose();
  }

  // ── Handlers ───────────────────────────────────────────────
  Future<void> _continueWithPhone() async {
    if (_phoneCtrl.text.trim().isEmpty) return;
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 800));
    setState(() { _loading = false; _showOtp = true; });
    _slideCtrl
      ..reset()
      ..forward();
    Future.delayed(const Duration(milliseconds: 100), () => _otpFoci[0].requestFocus());
  }

  Future<void> _verifyOtp() async {
    final code = _otpCtrls.map((c) => c.text).join();
    if (code.length < 6) return;
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 700));
    setState(() => _loading = false);
    if (!mounted) return;
    Navigator.pushReplacementNamed(context, '/role');
  }

  void _onOtpChanged(String v, int idx) {
    if (v.length == 1 && idx < 5) {
      _otpFoci[idx + 1].requestFocus();
    } else if (v.isEmpty && idx > 0) {
      _otpFoci[idx - 1].requestFocus();
    }
  }

  // ── Build ───────────────────────────────────────────────────
  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: M3Colors.petrolDark,
        body: Stack(
          children: [
            // Decorative circles
            _bgCircle(top: -80, right: -80, size: 280, opacity: 0.06),
            _bgCircle(bottom: -60, left: -60, size: 220, opacity: 0.05),
            _bgCircle(top: 200, left: -40, size: 140, opacity: 0.04),

            SafeArea(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 32),
                child: FadeTransition(
                  opacity: _fadeAnim,
                  child: SlideTransition(
                    position: _slideAnim,
                    child: _showOtp ? _buildOtpPanel() : _buildPhonePanel(),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ── Phone Panel ─────────────────────────────────────────────
  Widget _buildPhonePanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 40),
        // Logo
        Center(
          child: Container(
            width: 80, height: 80,
            decoration: BoxDecoration(
              color: M3Colors.green,
              borderRadius: BorderRadius.circular(24),
              boxShadow: [BoxShadow(color: M3Colors.green.withOpacity(0.4), blurRadius: 24, offset: const Offset(0, 8))],
            ),
            child: const Icon(Icons.school_rounded, color: Colors.white, size: 44),
          ),
        ),
        const SizedBox(height: 24),
        Text('م3علمي', textAlign: TextAlign.center,
            style: GoogleFonts.cairo(fontSize: 32, fontWeight: FontWeight.w900, color: Colors.white, letterSpacing: -0.5)),
        const SizedBox(height: 6),
        Text('منصة خدمات المعلمين والحرفيين', textAlign: TextAlign.center,
            style: GoogleFonts.cairo(fontSize: 14, color: Colors.white60, fontWeight: FontWeight.w500)),
        const SizedBox(height: 56),

        // Card
        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('تسجيل الدخول', style: GoogleFonts.cairo(fontSize: 20, fontWeight: FontWeight.w900, color: M3Colors.textPrimary)),
              const SizedBox(height: 4),
              Text('أدخل رقم هاتفك للمتابعة', style: GoogleFonts.cairo(fontSize: 13, color: M3Colors.textSec)),
              const SizedBox(height: 24),
              TextField(
                controller: _phoneCtrl,
                focusNode: _phoneFocus,
                keyboardType: TextInputType.phone,
                textDirection: TextDirection.ltr,
                textAlign: TextAlign.right,
                inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                decoration: const InputDecoration(
                  labelText: 'رقم الهاتف',
                  hintText: '05XXXXXXXX',
                  prefixIcon: Icon(Icons.phone_outlined, color: M3Colors.petrol),
                ),
                onSubmitted: (_) => _continueWithPhone(),
              ),
              const SizedBox(height: 20),
              _greenButton(
                label: 'استمرار',
                icon: Icons.arrow_back_rounded,
                loading: _loading,
                onPressed: _continueWithPhone,
              ),
              const SizedBox(height: 16),
              Center(
                child: Text('سيُرسَل رمز التحقق إلى هاتفك',
                    style: GoogleFonts.cairo(fontSize: 11.5, color: M3Colors.textMuted)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  // ── OTP Panel ───────────────────────────────────────────────
  Widget _buildOtpPanel() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: 40),
        Center(
          child: Container(
            width: 72, height: 72,
            decoration: BoxDecoration(
              color: M3Colors.petrol.withOpacity(0.15),
              borderRadius: BorderRadius.circular(20),
              border: Border.all(color: M3Colors.petrol.withOpacity(0.25)),
            ),
            child: const Icon(Icons.sms_outlined, color: Colors.white, size: 36),
          ),
        ),
        const SizedBox(height: 20),
        Text('رمز التحقق', textAlign: TextAlign.center,
            style: GoogleFonts.cairo(fontSize: 28, fontWeight: FontWeight.w900, color: Colors.white)),
        const SizedBox(height: 6),
        Text('أُرسل الرمز إلى ${_phoneCtrl.text}', textAlign: TextAlign.center,
            style: GoogleFonts.cairo(fontSize: 13, color: Colors.white60)),
        const SizedBox(height: 40),

        _card(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('أدخل الرمز المكون من 6 أرقام',
                  style: GoogleFonts.cairo(fontSize: 14, color: M3Colors.textSec)),
              const SizedBox(height: 20),

              // OTP boxes — LTR row
              Directionality(
                textDirection: TextDirection.ltr,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: List.generate(6, (i) => _otpBox(i)),
                ),
              ),
              const SizedBox(height: 10),
              // Demo hint
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                decoration: BoxDecoration(
                  color: M3Colors.petrolTint,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: M3Colors.petrol.withOpacity(0.12)),
                ),
                child: Text('💡 وضع تجريبي: أدخل أي 6 أرقام للمتابعة',
                    textAlign: TextAlign.center,
                    style: GoogleFonts.cairo(fontSize: 11.5, color: M3Colors.petrol, fontWeight: FontWeight.w600)),
              ),
              const SizedBox(height: 20),
              _greenButton(
                label: 'دخول',
                icon: Icons.login_rounded,
                loading: _loading,
                onPressed: _verifyOtp,
              ),
              const SizedBox(height: 14),
              TextButton(
                onPressed: () => setState(() { _showOtp = false; _slideCtrl..reset()..forward(); }),
                child: Text('تعديل رقم الهاتف',
                    style: GoogleFonts.cairo(color: M3Colors.petrol, fontWeight: FontWeight.w700, fontSize: 13)),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _otpBox(int i) {
    return SizedBox(
      width: 46, height: 54,
      child: TextField(
        controller: _otpCtrls[i],
        focusNode: _otpFoci[i],
        textAlign: TextAlign.center,
        keyboardType: TextInputType.number,
        maxLength: 1,
        inputFormatters: [FilteringTextInputFormatter.digitsOnly],
        style: GoogleFonts.cairo(fontSize: 22, fontWeight: FontWeight.w900, color: M3Colors.petrolDark),
        decoration: InputDecoration(
          counterText: '',
          contentPadding: EdgeInsets.zero,
          fillColor: M3Colors.petrolTint,
          filled: true,
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: M3Colors.petrol.withOpacity(0.2)),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: M3Colors.petrol, width: 2),
          ),
        ),
        onChanged: (v) => _onOtpChanged(v, i),
      ),
    );
  }

  // ── Helpers ─────────────────────────────────────────────────
  Widget _card({required Widget child}) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: M3Colors.petrolDark.withOpacity(0.2), blurRadius: 40, offset: const Offset(0, 16))],
      ),
      child: child,
    );
  }

  Widget _greenButton({required String label, required IconData icon, required bool loading, required VoidCallback onPressed}) {
    return SizedBox(
      height: 54,
      child: ElevatedButton(
        onPressed: loading ? null : onPressed,
        style: ElevatedButton.styleFrom(
          backgroundColor: M3Colors.green,
          disabledBackgroundColor: M3Colors.green.withOpacity(0.7),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: loading
            ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(label, style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                  const SizedBox(width: 8),
                  Icon(icon, size: 18, color: Colors.white),
                ],
              ),
      ),
    );
  }

  Widget _bgCircle({double? top, double? bottom, double? left, double? right, required double size, required double opacity}) {
    return Positioned(
      top: top, bottom: bottom, left: left, right: right,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(opacity),
          shape: BoxShape.circle,
        ),
      ),
    );
  }
}
