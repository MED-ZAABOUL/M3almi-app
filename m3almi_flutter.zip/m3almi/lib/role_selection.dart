// ══════════════════════════════════════════════════════════════
//  role_selection.dart — Profile Completion & Role Picker
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'main.dart';

enum UserRole { maalam, customer }

class RoleSelectionScreen extends StatefulWidget {
  const RoleSelectionScreen({super.key});
  @override
  State<RoleSelectionScreen> createState() => _RoleSelectionScreenState();
}

class _RoleSelectionScreenState extends State<RoleSelectionScreen> with TickerProviderStateMixin {
  final _nameCtrl = TextEditingController();
  UserRole? _role;
  bool _loading = false;

  late final AnimationController _enterCtrl;
  late final List<AnimationController> _cardCtrls;

  @override
  void initState() {
    super.initState();
    _enterCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 600))..forward();
    _cardCtrls = List.generate(2, (i) {
      final ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 400));
      Future.delayed(Duration(milliseconds: 300 + i * 120), ctrl.forward);
      return ctrl;
    });
  }

  @override
  void dispose() {
    _enterCtrl.dispose();
    for (final c in _cardCtrls) c.dispose();
    _nameCtrl.dispose();
    super.dispose();
  }

  Future<void> _confirm() async {
    if (_nameCtrl.text.trim().isEmpty || _role == null) return;
    setState(() => _loading = true);
    await Future.delayed(const Duration(milliseconds: 600));
    if (!mounted) return;
    setState(() => _loading = false);
    final route = _role == UserRole.maalam ? '/maalam' : '/customer';
    Navigator.pushReplacementNamed(context, route);
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: Stack(
          children: [
            // Gradient background
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [M3Colors.petrolDark, M3Colors.petrol, Color(0xFF006AAC)],
                  stops: [0, 0.55, 1],
                ),
              ),
            ),
            _circle(top: -60, right: -60, size: 220, opacity: 0.06),
            _circle(bottom: -40, left: -40, size: 180, opacity: 0.05),

            SafeArea(
              child: FadeTransition(
                opacity: CurvedAnimation(parent: _enterCtrl, curve: Curves.easeOut),
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 28),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      const SizedBox(height: 16),
                      _buildHeader(),
                      const SizedBox(height: 36),
                      _buildForm(),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Container(
          width: 72, height: 72,
          decoration: BoxDecoration(
            color: M3Colors.green.withOpacity(0.15),
            borderRadius: BorderRadius.circular(22),
            border: Border.all(color: M3Colors.green.withOpacity(0.3), width: 1.5),
          ),
          child: const Icon(Icons.person_add_alt_1_rounded, color: M3Colors.green, size: 38),
        ),
        const SizedBox(height: 16),
        Text('إكمال الملف الشخصي', textAlign: TextAlign.center,
            style: GoogleFonts.cairo(fontSize: 24, fontWeight: FontWeight.w900, color: Colors.white)),
        const SizedBox(height: 6),
        Text('خطوة واحدة فقط لتبدأ', textAlign: TextAlign.center,
            style: GoogleFonts.cairo(fontSize: 13, color: Colors.white60)),
      ],
    );
  }

  Widget _buildForm() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [BoxShadow(color: M3Colors.petrolDark.withOpacity(0.22), blurRadius: 40, offset: const Offset(0, 16))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Name field
          Text('اسمك الكامل', style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w700, color: M3Colors.textSec)),
          const SizedBox(height: 8),
          TextField(
            controller: _nameCtrl,
            decoration: const InputDecoration(
              hintText: 'مثال: أحمد بن سالم',
              prefixIcon: Icon(Icons.badge_outlined, color: M3Colors.petrol),
            ),
            onChanged: (_) => setState(() {}),
          ),
          const SizedBox(height: 28),

          // Role picker label
          Text('نوع حسابك', style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w700, color: M3Colors.textSec)),
          const SizedBox(height: 12),

          // Role cards
          SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
                .animate(CurvedAnimation(parent: _cardCtrls[0], curve: Curves.easeOutCubic)),
            child: FadeTransition(
              opacity: _cardCtrls[0],
              child: _roleCard(
                role: UserRole.maalam,
                icon: Icons.construction_rounded,
                title: 'أنا معلم',
                subtitle: 'قدّم خدماتك واكسب من مهاراتك',
                color: M3Colors.petrol,
                colorLight: M3Colors.petrolLight,
              ),
            ),
          ),
          const SizedBox(height: 12),
          SlideTransition(
            position: Tween<Offset>(begin: const Offset(0, 0.2), end: Offset.zero)
                .animate(CurvedAnimation(parent: _cardCtrls[1], curve: Curves.easeOutCubic)),
            child: FadeTransition(
              opacity: _cardCtrls[1],
              child: _roleCard(
                role: UserRole.customer,
                icon: Icons.search_rounded,
                title: 'أنا زبون',
                subtitle: 'ابحث عن معلم واطلب خدمة الآن',
                color: M3Colors.green,
                colorLight: M3Colors.greenTint,
              ),
            ),
          ),
          const SizedBox(height: 28),

          // Confirm button
          SizedBox(
            height: 54,
            child: ElevatedButton(
              onPressed: (_nameCtrl.text.trim().isNotEmpty && _role != null && !_loading)
                  ? _confirm
                  : null,
              style: ElevatedButton.styleFrom(
                backgroundColor: M3Colors.green,
                disabledBackgroundColor: M3Colors.textMuted.withOpacity(0.3),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
              ),
              child: _loading
                  ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2.5))
                  : Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text('تأكيد والدخول', style: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w800, color: Colors.white)),
                        const SizedBox(width: 8),
                        const Icon(Icons.arrow_back_rounded, size: 18, color: Colors.white),
                      ],
                    ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _roleCard({
    required UserRole role,
    required IconData icon,
    required String title,
    required String subtitle,
    required Color color,
    required Color colorLight,
  }) {
    final selected = _role == role;
    return GestureDetector(
      onTap: () => setState(() => _role = role),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 220),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: selected ? colorLight : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: selected ? color : M3Colors.petrol.withOpacity(0.12),
            width: selected ? 2 : 1,
          ),
          boxShadow: selected
              ? [BoxShadow(color: color.withOpacity(0.15), blurRadius: 16, offset: const Offset(0, 4))]
              : [BoxShadow(color: Colors.black.withOpacity(0.04), blurRadius: 8)],
        ),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              width: 52, height: 52,
              decoration: BoxDecoration(
                color: selected ? color : color.withOpacity(0.08),
                borderRadius: BorderRadius.circular(14),
              ),
              child: Icon(icon, color: selected ? Colors.white : color, size: 26),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: GoogleFonts.cairo(fontSize: 15, fontWeight: FontWeight.w800,
                      color: selected ? color : M3Colors.textPrimary)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: GoogleFonts.cairo(fontSize: 12, color: M3Colors.textSec)),
                ],
              ),
            ),
            AnimatedContainer(
              duration: const Duration(milliseconds: 220),
              width: 22, height: 22,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: selected ? color : Colors.transparent,
                border: Border.all(color: selected ? color : M3Colors.textMuted, width: 2),
              ),
              child: selected ? const Icon(Icons.check, size: 14, color: Colors.white) : null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _circle({double? top, double? bottom, double? left, double? right, required double size, required double opacity}) {
    return Positioned(
      top: top, bottom: bottom, left: left, right: right,
      child: Container(
        width: size, height: size,
        decoration: BoxDecoration(color: Colors.white.withOpacity(opacity), shape: BoxShape.circle),
      ),
    );
  }
}
