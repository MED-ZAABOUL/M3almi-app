// ══════════════════════════════════════════════════════════════
//  main.dart — M3almi App Entry Point
//  Theme · Routes · Bootstrap
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';
import 'auth_screen.dart';
import 'role_selection.dart';
import 'maalam_dashboard.dart';
import 'customer_dashboard.dart';

// ── Brand Colours ─────────────────────────────────────────────
class M3Colors {
  static const white   = Color(0xFFFFFFFF);
  static const petrol  = Color(0xFF005088);
  static const petrolDark = Color(0xFF003D6B);
  static const petrolLight = Color(0xFFE0EEF7);
  static const petrolTint  = Color(0xFFF0F7FC);
  static const green   = Color(0xFF22C55E);
  static const greenDark = Color(0xFF16A34A);
  static const greenTint = Color(0xFFDCFCE7);
  static const red     = Color(0xFFEF4444);
  static const amber   = Color(0xFFF59E0B);
  static const textPrimary = Color(0xFF0D1B2A);
  static const textSec     = Color(0xFF4A5568);
  static const textMuted   = Color(0xFF94A3B8);
  static const bg          = Color(0xFFF5F8FB);
  static const surface     = Color(0xFFFFFFFF);
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([DeviceOrientation.portraitUp]);
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
  ));
  runApp(const M3almiApp());
}

class M3almiApp extends StatelessWidget {
  const M3almiApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'M3almi',
      debugShowCheckedModeBanner: false,
      theme: _buildTheme(),
      initialRoute: '/auth',
      routes: {
        '/auth':     (_) => const AuthScreen(),
        '/role':     (_) => const RoleSelectionScreen(),
        '/maalam':   (_) => const MaalamDashboard(),
        '/customer': (_) => const CustomerDashboard(),
      },
    );
  }

  ThemeData _buildTheme() {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(
        seedColor: M3Colors.petrol,
        primary: M3Colors.petrol,
        secondary: M3Colors.green,
        error: M3Colors.red,
        surface: M3Colors.surface,
      ),
    );
    return base.copyWith(
      textTheme: GoogleFonts.cairoTextTheme(base.textTheme),
      scaffoldBackgroundColor: M3Colors.bg,
      appBarTheme: AppBarTheme(
        backgroundColor: M3Colors.petrol,
        foregroundColor: M3Colors.white,
        elevation: 0,
        titleTextStyle: GoogleFonts.cairo(
          color: M3Colors.white,
          fontSize: 18,
          fontWeight: FontWeight.w900,
        ),
        systemOverlayStyle: SystemUiOverlayStyle.light,
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: M3Colors.green,
          foregroundColor: M3Colors.white,
          elevation: 0,
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: GoogleFonts.cairo(fontSize: 16, fontWeight: FontWeight.w800),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: M3Colors.white,
        contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: M3Colors.petrol.withOpacity(0.15)),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide(color: M3Colors.petrol.withOpacity(0.15)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: M3Colors.petrol, width: 1.8),
        ),
        hintStyle: GoogleFonts.cairo(color: M3Colors.textMuted),
        labelStyle: GoogleFonts.cairo(color: M3Colors.petrol, fontWeight: FontWeight.w600),
      ),
    );
  }
}
