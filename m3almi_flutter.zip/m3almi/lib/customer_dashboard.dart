// ══════════════════════════════════════════════════════════════
//  customer_dashboard.dart — Customer Dashboard
// ══════════════════════════════════════════════════════════════

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'main.dart';

class CustomerDashboard extends StatefulWidget {
  const CustomerDashboard({super.key});
  @override
  State<CustomerDashboard> createState() => _CustomerDashboardState();
}

class _CustomerDashboardState extends State<CustomerDashboard> with TickerProviderStateMixin {
  int _navIndex = 0;
  int _activeCategory = 0;
  int? _ratingValue;

  late final AnimationController _headerCtrl;
  late final AnimationController _contentCtrl;

  @override
  void initState() {
    super.initState();
    _headerCtrl  = AnimationController(vsync: this, duration: const Duration(milliseconds: 650))..forward();
    _contentCtrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 550));
    Future.delayed(const Duration(milliseconds: 180), _contentCtrl.forward);
  }

  @override
  void dispose() {
    _headerCtrl.dispose();
    _contentCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: M3Colors.bg,
        body: Column(
          children: [
            _buildHeader(),
            Expanded(child: _buildBody()),
          ],
        ),
        bottomNavigationBar: _buildBottomNav(),
        floatingActionButton: _buildFab(),
        floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      ),
    );
  }

  // ── Header ──────────────────────────────────────────────────
  Widget _buildHeader() {
    return SlideTransition(
      position: Tween<Offset>(begin: const Offset(0, -0.3), end: Offset.zero)
          .animate(CurvedAnimation(parent: _headerCtrl, curve: Curves.easeOutCubic)),
      child: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [M3Colors.petrolDark, M3Colors.petrol],
          ),
        ),
        child: SafeArea(
          bottom: false,
          child: Padding(
            padding: const EdgeInsets.fromLTRB(20, 12, 20, 0),
            child: Column(
              children: [
                // Top row
                Row(
                  children: [
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('مساءً نورك 👋', style: GoogleFonts.cairo(fontSize: 12, color: Colors.white60)),
                        Text('م3علمي', style: GoogleFonts.cairo(
                          fontSize: 22, fontWeight: FontWeight.w900, color: Colors.white,
                          shadows: [Shadow(color: M3Colors.green.withOpacity(0.5), blurRadius: 12)],
                        )),
                      ],
                    ),
                    const Spacer(),
                    Stack(
                      children: [
                        Container(
                          width: 40, height: 40,
                          decoration: BoxDecoration(color: Colors.white.withOpacity(0.1), borderRadius: BorderRadius.circular(12)),
                          child: const Icon(Icons.notifications_outlined, color: Colors.white, size: 22),
                        ),
                        Positioned(
                          top: 7, left: 7,
                          child: Container(width: 9, height: 9, decoration: const BoxDecoration(color: M3Colors.red, shape: BoxShape.circle)),
                        ),
                      ],
                    ),
                    const SizedBox(width: 8),
                    Container(
                      width: 40, height: 40,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.12),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.white.withOpacity(0.2)),
                      ),
                      child: const Center(child: Text('👤', style: TextStyle(fontSize: 20))),
                    ),
                  ],
                ),
                const SizedBox(height: 16),

                // Search bar
                Container(
                  height: 50,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [BoxShadow(color: M3Colors.petrolDark.withOpacity(0.2), blurRadius: 12, offset: const Offset(0, 4))],
                  ),
                  child: Row(
                    children: [
                      const SizedBox(width: 14),
                      const Icon(Icons.search, color: M3Colors.petrol, size: 22),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text('ابحث عن معلم أو خدمة...',
                            style: GoogleFonts.cairo(fontSize: 13, color: M3Colors.textMuted)),
                      ),
                      Container(
                        margin: const EdgeInsets.all(6),
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(color: M3Colors.petrol, borderRadius: BorderRadius.circular(9)),
                        child: Text('بحث', style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),

                // Category chips
                SizedBox(
                  height: 36,
                  child: ListView.separated(
                    scrollDirection: Axis.horizontal,
                    itemCount: _categories.length,
                    separatorBuilder: (_, __) => const SizedBox(width: 8),
                    itemBuilder: (_, i) {
                      final active = _activeCategory == i;
                      return GestureDetector(
                        onTap: () => setState(() => _activeCategory = i),
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          padding: const EdgeInsets.symmetric(horizontal: 14),
                          decoration: BoxDecoration(
                            color: active ? M3Colors.green : Colors.white.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(10),
                            border: Border.all(color: active ? M3Colors.green : Colors.white.withOpacity(0.25)),
                          ),
                          child: Center(
                            child: Text(_categories[i],
                                style: GoogleFonts.cairo(
                                    fontSize: 11.5, fontWeight: FontWeight.w700,
                                    color: active ? Colors.white : Colors.white70)),
                          ),
                        ),
                      );
                    },
                  ),
                ),
                const SizedBox(height: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ── Body ────────────────────────────────────────────────────
  Widget _buildBody() {
    return FadeTransition(
      opacity: CurvedAnimation(parent: _contentCtrl, curve: Curves.easeOut),
      child: ListView(
        padding: const EdgeInsets.fromLTRB(18, 18, 18, 90),
        children: [
          // Active order banner
          _activeOrderBanner(),
          const SizedBox(height: 20),

          // Section: Featured Maalams
          _sectionHeader('معلمون مميزون', 'عرض الكل'),
          const SizedBox(height: 12),
          SizedBox(
            height: 180,
            child: ListView.separated(
              scrollDirection: Axis.horizontal,
              itemCount: _maalams.length,
              separatorBuilder: (_, __) => const SizedBox(width: 12),
              itemBuilder: (_, i) => _maalamCard(_maalams[i]),
            ),
          ),
          const SizedBox(height: 22),

          // Section: Request a service
          _sectionHeader('اطلب خدمة', null),
          const SizedBox(height: 12),
          _requestServiceCard(),
          const SizedBox(height: 22),

          // Section: Rate last service
          _sectionHeader('قيّم آخر خدمة', null),
          const SizedBox(height: 12),
          _ratingCard(),
          const SizedBox(height: 10),

          // Section: Recent orders
          _sectionHeader('طلباتي الأخيرة', 'عرض الكل'),
          const SizedBox(height: 12),
          ..._recentOrders.map((o) => _orderTile(o)),
        ],
      ),
    );
  }

  Widget _activeOrderBanner() {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [M3Colors.petrol, Color(0xFF006AAC)]),
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.3), blurRadius: 16, offset: const Offset(0, 6))],
      ),
      child: Row(
        children: [
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(color: Colors.white.withOpacity(0.15), borderRadius: BorderRadius.circular(13)),
            child: const Icon(Icons.engineering_outlined, color: Colors.white, size: 26),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('طلب #M3-20489 · جارٍ التنفيذ',
                    style: GoogleFonts.cairo(fontSize: 12, color: Colors.white70)),
                Text('علي بن حسين — سباكة', style: GoogleFonts.cairo(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white)),
                const SizedBox(height: 4),
                ClipRRect(
                  borderRadius: BorderRadius.circular(4),
                  child: LinearProgressIndicator(value: 0.65, minHeight: 5, backgroundColor: Colors.white24,
                      valueColor: const AlwaysStoppedAnimation(M3Colors.green)),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(color: M3Colors.green, borderRadius: BorderRadius.circular(10)),
            child: Text('تتبّع', style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Widget _maalamCard(Map<String, dynamic> m) {
    return Container(
      width: 150,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.08), blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 44, height: 44,
                decoration: BoxDecoration(color: M3Colors.petrolLight, shape: BoxShape.circle),
                child: Center(child: Text(m['avatar'], style: const TextStyle(fontSize: 22))),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                decoration: BoxDecoration(color: M3Colors.greenTint, borderRadius: BorderRadius.circular(7)),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.star_rounded, color: M3Colors.amber, size: 12),
                    const SizedBox(width: 2),
                    Text(m['rating'], style: GoogleFonts.cairo(fontSize: 10, fontWeight: FontWeight.w800, color: M3Colors.greenDark)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(m['name'], style: GoogleFonts.cairo(fontSize: 12.5, fontWeight: FontWeight.w800, color: M3Colors.textPrimary)),
          const SizedBox(height: 2),
          Text(m['specialty'], style: GoogleFonts.cairo(fontSize: 10.5, color: M3Colors.textSec)),
          const Spacer(),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton(
              onPressed: () {},
              style: ElevatedButton.styleFrom(
                backgroundColor: M3Colors.green,
                padding: const EdgeInsets.symmetric(vertical: 8),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(9)),
              ),
              child: Text('طلب', style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w800, color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _requestServiceCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.08), blurRadius: 12, offset: const Offset(0, 4))],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              const Icon(Icons.build_circle_outlined, color: M3Colors.petrol, size: 20),
              const SizedBox(width: 8),
              Text('اشرح مشكلتك', style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w800, color: M3Colors.textPrimary)),
            ],
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: M3Colors.bg,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: M3Colors.petrol.withOpacity(0.1)),
            ),
            child: Text('اشرح المشكلة بكل التفاصيل...',
                style: GoogleFonts.cairo(fontSize: 13, color: M3Colors.textMuted)),
          ),
          const SizedBox(height: 12),
          // Service type chips
          Wrap(
            spacing: 8, runSpacing: 8,
            children: ['🔧 سباكة', '💡 كهرباء', '🎨 دهانات', '❄️ تكييف', '🪚 نجارة'].map((c) {
              return Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                decoration: BoxDecoration(
                  color: M3Colors.petrolLight,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: M3Colors.petrol.withOpacity(0.15)),
                ),
                child: Text(c, style: GoogleFonts.cairo(fontSize: 11, fontWeight: FontWeight.w700, color: M3Colors.petrol)),
              );
            }).toList(),
          ),
          const SizedBox(height: 14),
          ElevatedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.send_rounded, size: 16, color: Colors.white),
            label: Text('إرسال الطلب', style: GoogleFonts.cairo(fontSize: 14, fontWeight: FontWeight.w800, color: Colors.white)),
            style: ElevatedButton.styleFrom(
              backgroundColor: M3Colors.green,
              padding: const EdgeInsets.symmetric(vertical: 13),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _ratingCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: M3Colors.petrol.withOpacity(0.08)),
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.07), blurRadius: 10)],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40, height: 40,
                decoration: BoxDecoration(color: M3Colors.petrolLight, shape: BoxShape.circle),
                child: const Center(child: Text('🧑‍🔧', style: TextStyle(fontSize: 20))),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('علي بن حسين', style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w800, color: M3Colors.textPrimary)),
                    Text('أنهى العمل بنجاح 🎉', style: GoogleFonts.cairo(fontSize: 11, color: M3Colors.textSec)),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(color: M3Colors.greenTint, borderRadius: BorderRadius.circular(8)),
                child: Text('مكتملة', style: GoogleFonts.cairo(fontSize: 10, fontWeight: FontWeight.w700, color: M3Colors.greenDark)),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Text('قيّمه الآن:', style: GoogleFonts.cairo(fontSize: 12, color: M3Colors.textSec, fontWeight: FontWeight.w600)),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: List.generate(5, (i) {
              final filled = _ratingValue != null && i < _ratingValue!;
              return GestureDetector(
                onTap: () => setState(() => _ratingValue = i + 1),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Icon(
                    filled ? Icons.star_rounded : Icons.star_outline_rounded,
                    color: filled ? M3Colors.amber : M3Colors.textMuted,
                    size: 36,
                  ),
                ),
              );
            }),
          ),
          if (_ratingValue != null) ...[
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () => setState(() => _ratingValue = null),
                style: ElevatedButton.styleFrom(
                  backgroundColor: M3Colors.green,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(11)),
                ),
                child: Text('إرسال التقييم ⭐', style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w800, color: Colors.white)),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _orderTile(Map<String, dynamic> o) {
    return Container(
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.05), blurRadius: 8)],
      ),
      child: Row(
        children: [
          Container(
            width: 42, height: 42,
            decoration: BoxDecoration(color: M3Colors.petrolLight, borderRadius: BorderRadius.circular(12)),
            child: Center(child: Text(o['emoji'], style: const TextStyle(fontSize: 20))),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(o['title'], style: GoogleFonts.cairo(fontSize: 12.5, fontWeight: FontWeight.w800, color: M3Colors.textPrimary)),
                Text(o['date'], style: GoogleFonts.cairo(fontSize: 10.5, color: M3Colors.textMuted)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(o['price'], style: GoogleFonts.cairo(fontSize: 13, fontWeight: FontWeight.w800, color: M3Colors.petrol)),
              const SizedBox(height: 4),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: o['status'] == 'مكتملة' ? M3Colors.greenTint : M3Colors.petrolLight,
                  borderRadius: BorderRadius.circular(7),
                ),
                child: Text(o['status'],
                    style: GoogleFonts.cairo(fontSize: 9.5, fontWeight: FontWeight.w700,
                        color: o['status'] == 'مكتملة' ? M3Colors.greenDark : M3Colors.petrol)),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ── FAB ─────────────────────────────────────────────────────
  Widget _buildFab() {
    return FloatingActionButton.extended(
      onPressed: () {},
      backgroundColor: M3Colors.green,
      elevation: 4,
      label: Row(
        children: [
          const Icon(Icons.add_circle_outline, color: Colors.white, size: 18),
          const SizedBox(width: 6),
          Text('طلب جديد', style: GoogleFonts.cairo(fontWeight: FontWeight.w800, color: Colors.white)),
        ],
      ),
    );
  }

  // ── Bottom Nav ───────────────────────────────────────────────
  Widget _buildBottomNav() {
    const items = [
      {'icon': Icons.home_rounded,        'label': 'الرئيسية'},
      {'icon': Icons.list_alt_rounded,    'label': 'طلباتي'},
      {'icon': Icons.chat_bubble_outline, 'label': 'رسائل'},
      {'icon': Icons.person_outline,     'label': 'حسابي'},
    ];
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        boxShadow: [BoxShadow(color: M3Colors.petrol.withOpacity(0.08), blurRadius: 20, offset: const Offset(0, -4))],
      ),
      child: SafeArea(
        top: false,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
          child: Row(
            children: List.generate(items.length, (i) {
              // gap in middle for FAB
              if (i == 2) return const SizedBox(width: 64);
              final active = _navIndex == i;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _navIndex = i),
                  behavior: HitTestBehavior.opaque,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Container(
                        height: 3,
                        margin: const EdgeInsets.symmetric(horizontal: 12),
                        decoration: BoxDecoration(
                          color: active ? M3Colors.petrol : Colors.transparent,
                          borderRadius: BorderRadius.circular(2),
                        ),
                      ),
                      const SizedBox(height: 6),
                      Icon(items[i]['icon'] as IconData,
                          color: active ? M3Colors.petrol : M3Colors.textMuted, size: 22),
                      const SizedBox(height: 3),
                      Text(items[i]['label'] as String,
                          style: GoogleFonts.cairo(
                              fontSize: 9.5, fontWeight: active ? FontWeight.w800 : FontWeight.w500,
                              color: active ? M3Colors.petrol : M3Colors.textMuted)),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }

  // ── Mock Data ────────────────────────────────────────────────
  final _categories = ['الكل', 'سباكة', 'كهرباء', 'دهانات', 'نجارة', 'تكييف'];

  final _maalams = [
    {'name': 'علي الشمري', 'avatar': '🧑‍🔧', 'specialty': 'سباكة وصحية', 'rating': '4.9'},
    {'name': 'محمد الغامدي', 'avatar': '👨‍🔧', 'specialty': 'كهرباء منزلية', 'rating': '4.8'},
    {'name': 'فهد العنزي', 'avatar': '🪚', 'specialty': 'نجارة وأثاث', 'rating': '4.7'},
    {'name': 'سلطان الحربي', 'avatar': '🎨', 'specialty': 'دهانات وديكور', 'rating': '4.9'},
  ];

  final _recentOrders = [
    {'emoji': '💡', 'title': 'تركيب نقاط إضاءة', 'date': 'البارحة · 3:00 م', 'price': '250 ر.س', 'status': 'مكتملة'},
    {'emoji': '🔧', 'title': 'إصلاح تسرب مياه', 'date': '28 مايو · 10:00 ص', 'price': '350 ر.س', 'status': 'مكتملة'},
    {'emoji': '❄️', 'title': 'صيانة مكيف سبليت', 'date': '22 مايو · 2:00 م', 'price': '200 ر.س', 'status': 'مكتملة'},
  ];
}
